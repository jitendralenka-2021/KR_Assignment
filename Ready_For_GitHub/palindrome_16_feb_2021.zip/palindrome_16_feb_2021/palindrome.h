#ifndef PALINDROME_H
#define PALINDROME_H

#include <iostream>
#include <string>
#include <algorithm>
#include <sstream>

using std::cout;
using std::string;
using std::transform;
using std::stringstream;

//Enable/Disable log.
bool static g_IS_LOG_ENABLE=true; //it should be placed in .cpp file.
void EnableDiableLog(bool InIsLog);
bool GetLogVal();
void Log(string InlogStr);

//Main API
bool IsPalindrome(string InString);

//Helper functions
bool IsValidInput(string & InString);
void TrimLeadingAndTrailingSpace(string & InString);
bool processStrChars(string InStr);

#endif